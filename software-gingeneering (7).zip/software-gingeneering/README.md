# Software Gingeneering — Interactive Dev Lab

An interactive web experience that teaches the **Software Development Life Cycle (SDLC)** through soft skills.

Visitors answer 5 fun scenario questions about how they handle real engineering situations. They receive a personalized **Gingeneer Profile**, see their strongest soft skills, and explore an interactive SDLC map that connects people skills to every phase of building software.

Perfect for booths, career fairs, classrooms, or workshops.

---

## Concept

**Software Gingeneering** = Software Engineering with a playful twist.

The experience is framed as a **mock tech startup / Interactive Dev Lab** with two zones:

| Zone | Focus |
|------|--------|
| **⌨ Keyboard Zone** | Technical outputs, code snippets, SDLC phases |
| **🤝 Collaboration Zone** | Soft skills, teamwork, communication |

---

## Features

- Touch-friendly UI designed for tablets
- 5 scenario-based soft-skill questions
- Personalized archetype (e.g. *The Bridge Builder*, *The Bug Whisperer*)
- Animated skill bars
- Interactive 6-phase SDLC Power Map
- Pure HTML/CSS/JS — no build step, no backend
- Works offline after first load (Google Fonts optional)

---

## Quick Start

1. Open `index.html` in any modern browser (Chrome, Safari, Edge, Firefox).
2. For a booth: put the tablet in full-screen / kiosk mode.
3. That’s it — no server required.

### Local server (optional)

If you prefer serving it properly:

```bash
# Python
python -m http.server 8080

# Node
npx serve .
```

Then visit `http://localhost:8080`.

---

## Project Structure

```
software-gingeneering/
├── index.html      # Complete app (HTML + CSS + JS)
└── README.md       # This file
```

---

## Customization

All content lives inside `index.html`:

- **Questions** → `questions` array
- **SDLC phases** → `phases` array
- **Archetypes** → `archetypes` object
- **Colors & styling** → CSS variables at the top of `<style>`

---

## License

Free to use and modify for educational and event purposes.
